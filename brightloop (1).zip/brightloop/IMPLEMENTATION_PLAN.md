# Brightloop — Implementation Plan (execute in this order)

## Goal
One professional, simple Subscription Management System for Brightloop Software,
exactly as in the problem-statement PDF, plus a few scaling extras. No flashy
effects. One separate page per feature, so a judge can click the sidebar and
see each feature working on its own page.

## UI rules (simple + professional, no AI filters)
- Flat colours only: navy #14213d, teal #0e8a8c / #0a6b6d, amber #f2a541,
  light grey background #f4f7f9, white cards, thin grey borders.
- NO gradients, NO blur/glow filters, NO animations, NO shadows that look
  like a poster. Every page uses the same layout: left sidebar + white card
  + one table or one form + one primary button.
- Fonts: Bricolage Grotesque for headings, Figtree for body. Same button,
  same table, same status pill on every page.
- Every list page: search box at the top, 25 rows per page, Open button per row.
- Every form page: one form, one title that says what it does, one Save button.

## Stack (already decided, do not change mid-build)
- Backend: Django (Python), database: SQLite (single file db.sqlite3).
- Frontend: Django templates (HTML + CSS). No React, no build step.
- LocalStorage is NOT a database — all data is in SQLite, so admin, staff
  and customer see the same data.
- Run locally: venv -> pip install -> migrate -> seed_demo -> runserver.
  Netlify cannot host Django; live hosting later = Render/Railway.

## Phase 0 — Done (foundation)
Login / signup / password rules (>8 chars, uppercase + lowercase + special,
one account per email) / password-reset link. Roles: admin (full control),
staff (day-to-day, no staff creation, no discounts), customer (own data only).

## Phase 1 — Catalogue (separate pages)
1. /products/ — list, search. /products/new/ — form. /products/<id>/ — detail
   with its variants and plans.
2. /variants/ — list. /variants/new/ — form (e.g. Brand: Odoo +560).
3. /plans/ — list, search. /plans/new/ — form (daily/weekly/monthly/yearly,
   price, min quantity, availability dates, auto-close / pause / renew flags).
   /plans/<id>/ — detail with subscriptions using this plan.
4. /templates/ — list. /templates/new/ — form (plan + validity in days).

## Phase 2 — Subscriptions (separate pages)
5. /subscriptions/ — list, search, auto-close check button (closes expired
   subscriptions whose plan has auto_close on).
6. /subscriptions/new/ — form (plan can be pre-selected from /plans/).
7. /subscriptions/<id>/ — detail: lines, status flow
   Draft -> Quotation -> Confirmed -> Active -> Closed, plus Pause and Renew
   buttons that respect the plan's allow_pause / allow_renew flags.
   Add line checks the plan minimum quantity.

## Phase 3 — Billing (separate pages, PDF core)
8. /invoices/ — list, status filter. /invoices/<id>/ — detail: confirm /
   cancel / send / print actions, paid vs outstanding shown.
9. /subscriptions/<id>/invoice/ — generate one invoice for this month.
   Auto tax 18% from lines, auto discount (first active discount that fits),
   and NO double billing: one invoice per subscription per billing period
   (unique subscription + period in the database).
10. /invoices/bulk/ — NEW extra: generate invoices for ALL Active
    subscriptions for one billing period in one click, with a created /
    already-invoiced (skipped, not duplicated) report.
11. /discounts/ — list, search. /discounts/new/ — admin only (fixed or %,
    min purchase / quantity, start/end dates, usage limit, product-level or
    whole-subscription). Auto-applies on next invoice, stops on expiry/limit.
12. /payments/ — list, search. /payments/new/ — form (method, amount, date,
    note). Full payment flips the invoice to Paid automatically.

## Phase 4 — Reports + scaling extras (separate pages)
13. / — Finance Dashboard: active subs, total subs, revenue (payments),
    outstanding, overdue, recent invoices with status pills.
14. /reports/ — NEW extra: revenue by month, revenue by plan, top customers,
    overdue list, outstanding by customer. Aggregates only (no full-table
    scan in the template), so it stays fast with thousands of rows.
15. CSV export — NEW extra: /invoices/export/ and /payments/export/
    download a CSV of the current list, for accounts / Excel.
16. Portals — separate pages per role: /admin-portal/ (admin only),
    /staff-portal/ (staff + admin), /portal/ (customer, own data only).

## Phase 5 — Polish, freeze, submit (today, 2pm freeze, 3pm submit)
- Run: python manage.py check, migrate, seed_demo (safe to re-run),
  runserver, click every sidebar link as admin, staff and customer.
- Check: customer cannot open admin/staff pages, staff cannot create staff
  or discounts, same invoice cannot be generated twice, weak password is
  rejected, duplicate email is rejected.
- Freeze code at 2pm. Record video 2-3pm: login/roles -> product/plan ->
  subscription -> invoice (live, SUB-0001) -> no-double-billing proof ->
  payment/discount -> dashboard/reports. Team leader submits the single-branch
  GitHub repo link + video link before 3pm, screenshots the confirmation.

## Page map (one page = one job)
Dashboard / | Admin Portal | Staff Portal | My Portal | Products | Variants |
Plans | Templates | Subscriptions | Subscription detail | Invoices | Invoice
detail | Bulk Invoices | Discounts | Payments | Reports | Add Staff (admin)

## PDF coverage checklist
Auth + roles + password rule + reset | Products + variants | Plans (all
frequencies, min qty, dates, auto-close/pause/renew) | Quotation templates |
Subscriptions + lines + status flow | Invoices (auto tax, Draft->Confirmed->
Paid, confirm/cancel/send/print, no double billing, no skipping) | Discounts
(admin only, fixed/%, limits, auto on next invoice) | Payments (method/
amount/date/note, paid vs outstanding/overdue) | Dashboard (active, revenue,
payments, overdue, filters, fast with thousands) — all implemented.
