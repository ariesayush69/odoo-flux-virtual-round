from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from decimal import Decimal

ROLE_CHOICES = [('admin', 'Admin'), ('staff', 'Staff'), ('customer', 'Customer')]

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='customer')
    def __str__(self):
        return f"{self.user.email} ({self.role})"

class TaxRule(models.Model):
    name = models.CharField(max_length=100)
    rate_percent = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('18.00'))
    def __str__(self):
        return f"{self.name} {self.rate_percent}%"

class Product(models.Model):
    name = models.CharField(max_length=200)
    type = models.CharField(max_length=100, help_text='e.g. Software, Add-on')
    sales_price = models.DecimalField(max_digits=10, decimal_places=2)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2)
    notes = models.TextField(blank=True)
    def __str__(self):
        return self.name

class Variant(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='variants')
    name = models.CharField(max_length=200, help_text='e.g. Brand: Odoo')
    price_add = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0'))
    def __str__(self):
        return f"{self.product.name} - {self.name} (+{self.price_add})"

FREQ = [('daily', 'Daily'), ('weekly', 'Weekly'), ('monthly', 'Monthly'), ('yearly', 'Yearly')]

class Plan(models.Model):
    name = models.CharField(max_length=200)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True)
    billing_frequency = models.CharField(max_length=20, choices=FREQ, default='monthly')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    min_quantity = models.PositiveIntegerField(default=1)
    available_from = models.DateField(null=True, blank=True)
    available_to = models.DateField(null=True, blank=True)
    auto_close = models.BooleanField(default=False, help_text='Close on its own when it ends')
    allow_pause = models.BooleanField(default=True)
    allow_early_close = models.BooleanField(default=True)
    allow_renew = models.BooleanField(default=True)
    def __str__(self):
        return f"{self.name} ({self.billing_frequency} - {self.price})"

class QuotationTemplate(models.Model):
    name = models.CharField(max_length=200)
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE)
    validity_days = models.PositiveIntegerField(default=30)
    notes = models.TextField(blank=True)
    def __str__(self):
        return self.name

SUB_STATUS = [('Draft', 'Draft'), ('Quotation', 'Quotation'), ('Confirmed', 'Confirmed'),
              ('Active', 'Active'), ('Paused', 'Paused'), ('Closed', 'Closed')]
SUB_ORDER = ['Draft', 'Quotation', 'Confirmed', 'Active', 'Closed']

class Subscription(models.Model):
    number = models.CharField(max_length=50, unique=True, blank=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='subscriptions')
    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)
    template = models.ForeignKey(QuotationTemplate, on_delete=models.SET_NULL, null=True, blank=True)
    start_date = models.DateField()
    expiry_date = models.DateField()
    payment_terms = models.CharField(max_length=200, default='Net 30')
    status = models.CharField(max_length=20, choices=SUB_STATUS, default='Draft')
    created_at = models.DateTimeField(auto_now_add=True)
    def save(self, *args, **kwargs):
        if not self.number:
            last = Subscription.objects.order_by('-id').first()
            self.number = f"SUB-{(last.id + 1) if last else 1:04d}"
        super().save(*args, **kwargs)
    def __str__(self):
        return f"{self.number} - {self.customer.email} - {self.status}"

class SubscriptionLine(models.Model):
    subscription = models.ForeignKey(Subscription, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    variant = models.ForeignKey(Variant, on_delete=models.SET_NULL, null=True, blank=True)
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('18.00'))
    @property
    def amount(self):
        base = self.unit_price * self.quantity
        if self.variant:
            base += self.variant.price_add * self.quantity
        return base
    @property
    def tax_amount(self):
        return self.amount * self.tax_percent / Decimal('100')
    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

INV_STATUS = [('Draft', 'Draft'), ('Confirmed', 'Confirmed'), ('Paid', 'Paid'), ('Cancelled', 'Cancelled')]

class Invoice(models.Model):
    number = models.CharField(max_length=50, unique=True, blank=True)
    subscription = models.ForeignKey(Subscription, on_delete=models.PROTECT, related_name='invoices')
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='invoices')
    billing_period = models.DateField(help_text='Billing month / period start - one invoice per subscription per period')
    status = models.CharField(max_length=20, choices=INV_STATUS, default='Draft')
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0'))
    tax_total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0'))
    discount_total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0'))
    total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0'))
    due_date = models.DateField(null=True, blank=True)
    sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        # This is the no-double-billing rule: same subscription + period = only 1 invoice.
        unique_together = [('subscription', 'billing_period')]
    def save(self, *args, **kwargs):
        if not self.number:
            last = Invoice.objects.order_by('-id').first()
            self.number = f"INV-{(last.id + 1) if last else 1:04d}"
        super().save(*args, **kwargs)
    @property
    def paid_amount(self):
        return sum((p.amount for p in self.payments.all()), Decimal('0'))
    @property
    def outstanding(self):
        return self.total - self.paid_amount
    def __str__(self):
        return f"{self.number} - {self.status} - {self.total}"

class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0'))
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

DISC_TYPE = [('fixed', 'Fixed amount'), ('percent', 'Percentage')]

class Discount(models.Model):
    name = models.CharField(max_length=200)
    code = models.CharField(max_length=50, unique=True)
    discount_type = models.CharField(max_length=20, choices=DISC_TYPE, default='percent')
    value = models.DecimalField(max_digits=10, decimal_places=2)
    min_purchase = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0'))
    min_quantity = models.PositiveIntegerField(default=0)
    start_date = models.DateField()
    end_date = models.DateField()
    usage_limit = models.PositiveIntegerField(default=100)
    used_count = models.PositiveIntegerField(default=0)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True,
                                help_text='Leave blank = applies to whole subscription')
    def is_active_on(self, on_date, subtotal=Decimal('0'), qty=0):
        if not (self.start_date <= on_date <= self.end_date):
            return False
        if self.used_count >= self.usage_limit:
            return False
        if subtotal < self.min_purchase or qty < self.min_quantity:
            return False
        return True
    def amount_for(self, subtotal):
        if self.discount_type == 'fixed':
            return min(self.value, subtotal)
        return subtotal * self.value / Decimal('100')
    def __str__(self):
        return f"{self.code} ({self.discount_type} {self.value})"

PAY_METHODS = [('Cash', 'Cash'), ('UPI', 'UPI'), ('Card', 'Card'), ('Bank Transfer', 'Bank Transfer'), ('Other', 'Other')]

class Payment(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='payments')
    method = models.CharField(max_length=30, choices=PAY_METHODS, default='UPI')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    note = models.CharField(max_length=300, blank=True)
    def __str__(self):
        return f"{self.invoice.number} - {self.method} {self.amount}"
