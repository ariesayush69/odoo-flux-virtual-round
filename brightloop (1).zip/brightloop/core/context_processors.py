def user_role(request):
    role = ''
    user = getattr(request, 'user', None)
    if user and user.is_authenticated:
        try:
            role = user.profile.role
        except Exception:
            role = 'customer' if not user.is_superuser else 'admin'
    return {'user_role': role}
