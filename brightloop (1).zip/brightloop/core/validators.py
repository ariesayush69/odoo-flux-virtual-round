"""Password rules from the Brightloop PDF:
more than 8 characters, with 1 uppercase, 1 lowercase, 1 special character."""
import re
from django.core.exceptions import ValidationError

class MinLength9Validator:
    def validate(self, password, user=None):
        if len(password) <= 8:
            raise ValidationError('Password must be more than 8 characters.')
    def get_help_text(self):
        return 'Your password must be more than 8 characters long.'

class UppercaseValidator:
    def validate(self, password, user=None):
        if not re.search(r'[A-Z]', password):
            raise ValidationError('Password must contain at least one uppercase letter.')
    def get_help_text(self):
        return 'Your password must contain at least one uppercase letter.'

class LowercaseValidator:
    def validate(self, password, user=None):
        if not re.search(r'[a-z]', password):
            raise ValidationError('Password must contain at least one lowercase letter.')
    def get_help_text(self):
        return 'Your password must contain at least one lowercase letter.'

class SpecialCharValidator:
    def validate(self, password, user=None):
        if not re.search(r'[^A-Za-z0-9]', password):
            raise ValidationError('Password must contain at least one special character.')
    def get_help_text(self):
        return 'Your password must contain at least one special character.'
