from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from .models import Product, Variant, Plan, QuotationTemplate, Subscription, SubscriptionLine, Discount, Payment

class SignupForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    def clean_email(self):
        email = self.cleaned_data['email'].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('This email already has an account. Use login, or reset password.')
        return email
    def clean_password(self):
        validate_password(self.cleaned_data.get('password', ''))
        return self.cleaned_data['password']

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product; fields = '__all__'
class VariantForm(forms.ModelForm):
    class Meta:
        model = Variant; fields = '__all__'
class PlanForm(forms.ModelForm):
    class Meta:
        model = Plan; fields = '__all__'
        widgets = {'available_from': forms.DateInput(attrs={'type': 'date'}),
                   'available_to': forms.DateInput(attrs={'type': 'date'})}
class TemplateForm(forms.ModelForm):
    class Meta:
        model = QuotationTemplate; fields = '__all__'
class SubscriptionForm(forms.ModelForm):
    class Meta:
        model = Subscription; fields = ['customer', 'plan', 'template', 'start_date', 'expiry_date', 'payment_terms']
        widgets = {'start_date': forms.DateInput(attrs={'type': 'date'}),
                   'expiry_date': forms.DateInput(attrs={'type': 'date'})}
    def clean(self):
        data = super().clean()
        plan, lines_qty = data.get('plan'), 1
        # min_quantity is checked again when lines are added; plan-level guard here:
        if plan and plan.min_quantity < 1:
            raise forms.ValidationError('Plan minimum quantity must be at least 1.')
        return data
class SubscriptionLineForm(forms.ModelForm):
    class Meta:
        model = SubscriptionLine; fields = ['product', 'variant', 'quantity', 'unit_price', 'tax_percent']
class DiscountForm(forms.ModelForm):
    class Meta:
        model = Discount; fields = '__all__'
        widgets = {'start_date': forms.DateInput(attrs={'type': 'date'}),
                   'end_date': forms.DateInput(attrs={'type': 'date'})}
class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment; fields = ['invoice', 'method', 'amount', 'date', 'note']
        widgets = {'date': forms.DateInput(attrs={'type': 'date'})}
class StaffForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    def clean_email(self):
        email = self.cleaned_data['email'].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('This email already has an account.')
        return email
    def clean_password(self):
        validate_password(self.cleaned_data.get('password', ''))
        return self.cleaned_data['password']
