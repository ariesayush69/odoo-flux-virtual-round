from django.contrib import admin
from .models import Profile, TaxRule, Product, Variant, Plan, QuotationTemplate, Subscription, SubscriptionLine, Invoice, InvoiceLine, Discount, Payment
for m in [Profile, TaxRule, Product, Variant, Plan, QuotationTemplate, Subscription, SubscriptionLine, Invoice, InvoiceLine, Discount, Payment]:
    admin.site.register(m)
