from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from decimal import Decimal
from datetime import date, timedelta
from core.models import Profile, Product, Variant, Plan, Subscription, SubscriptionLine, Invoice, InvoiceLine, Payment, Discount

class Command(BaseCommand):
    help = 'Create demo users, products, plans, active subscriptions, invoices and payments. Demo only. Safe to run again - it will not duplicate.'
    def handle(self, *args, **kwargs):
        def user(email, role, pw):
            u, created = User.objects.get_or_create(username=email, defaults={'email': email})
            u.set_password(pw); u.save()
            Profile.objects.update_or_create(user=u, defaults={'role': role})
            return u
        admin = user('admin@brightloop.test', 'admin', 'Admin@1234')
        staff = user('staff@brightloop.test', 'staff', 'Staff@1234')
        user('neha@brightloop.test', 'staff', 'Neha@1234')
        cust = user('customer@brightloop.test', 'customer', 'Customer@1234')
        prod, _ = Product.objects.get_or_create(name='Brightloop CRM', defaults={'type': 'Software', 'sales_price': Decimal('1000'), 'cost_price': Decimal('400'), 'notes': 'Business software, monthly billing'})
        var, _ = Variant.objects.get_or_create(product=prod, name='Brand: Odoo', defaults={'price_add': Decimal('560')})
        analytics, _ = Product.objects.get_or_create(name='Brightloop Analytics', defaults={'type': 'Software', 'sales_price': Decimal('1500'), 'cost_price': Decimal('600'), 'notes': 'Reports and dashboards'})
        support, _ = Product.objects.get_or_create(name='Brightloop Support', defaults={'type': 'Add-on', 'sales_price': Decimal('500'), 'cost_price': Decimal('200'), 'notes': 'Priority support add-on'})
        plan, _ = Plan.objects.get_or_create(name='Pro Monthly', defaults={'product': prod, 'billing_frequency': 'monthly', 'price': Decimal('1000'), 'min_quantity': 1, 'available_from': date.today(), 'auto_close': False})
        Plan.objects.get_or_create(name='Starter Monthly', defaults={'product': prod, 'billing_frequency': 'monthly', 'price': Decimal('499'), 'min_quantity': 1, 'available_from': date.today()})
        Plan.objects.get_or_create(name='Pro Yearly', defaults={'product': prod, 'billing_frequency': 'yearly', 'price': Decimal('10000'), 'min_quantity': 1, 'available_from': date.today()})
        analytics_plan, _ = Plan.objects.get_or_create(name='Analytics Monthly', defaults={'product': analytics, 'billing_frequency': 'monthly', 'price': Decimal('1500'), 'min_quantity': 1, 'available_from': date.today()})
        support_plan, _ = Plan.objects.get_or_create(name='Support Monthly', defaults={'product': support, 'billing_frequency': 'monthly', 'price': Decimal('500'), 'min_quantity': 1, 'available_from': date.today()})
        sub, created = Subscription.objects.get_or_create(number='SUB-0001', defaults={'customer': cust, 'plan': plan, 'start_date': date.today(), 'expiry_date': date.today() + timedelta(days=365), 'payment_terms': 'Net 30', 'status': 'Active'})
        if created:
            SubscriptionLine.objects.create(subscription=sub, product=prod, variant=var, quantity=2, unit_price=Decimal('1000'), tax_percent=Decimal('18'))
        # Dummy ACTIVE customers + subscriptions. SUB-0001 is deliberately left
        # without an invoice, so it can still be invoiced live in the video demo.
        dummies = [
            ('SUB-0002', 'priya@brightloop.test', 'Priya@1234', plan, prod, var, 1, 'Confirmed', 'UPI', None),
            ('SUB-0003', 'rahul@brightloop.test', 'Rahul@1234', analytics_plan, analytics, None, 2, 'Paid', 'UPI', 'full'),
            ('SUB-0004', 'sneha@brightloop.test', 'Sneha@1234', analytics_plan, analytics, None, 1, 'Confirmed', None, None),
            ('SUB-0005', 'arjun@brightloop.test', 'Arjun@1234', plan, prod, var, 1, 'Paid', 'Card', 'full'),
            ('SUB-0006', 'vikram@brightloop.test', 'Vikram@1234', support_plan, support, None, 3, 'Draft', None, None),
        ]
        period = date(2026, 10, 1)
        for number, email, pw, pl, pr, vr, qty, inv_status, pay_method, pay_full in dummies:
            cu = user(email, 'customer', pw)
            s, s_created = Subscription.objects.get_or_create(number=number, defaults={'customer': cu, 'plan': pl, 'start_date': date.today(), 'expiry_date': date.today() + timedelta(days=365), 'payment_terms': 'Net 30', 'status': 'Active'})
            if s_created:
                SubscriptionLine.objects.create(subscription=s, product=pr, variant=vr, quantity=qty, unit_price=pr.sales_price, tax_percent=Decimal('18'))
            # Invoice for this dummy subscription only (not for SUB-0001).
            if not Invoice.objects.filter(subscription=s, billing_period=period).exists():
                lines = list(s.lines.all())
                subtotal = sum((l.amount for l in lines), Decimal('0'))
                tax_total = sum((l.tax_amount for l in lines), Decimal('0'))
                inv = Invoice.objects.create(subscription=s, customer=cu, billing_period=period, status=inv_status, subtotal=subtotal, tax_total=tax_total, total=subtotal + tax_total, due_date=date.today() + timedelta(days=30))
                for l in lines:
                    InvoiceLine.objects.create(invoice=inv, product=l.product, quantity=l.quantity, unit_price=l.unit_price, tax_amount=l.tax_amount, amount=l.amount)
                if pay_full:
                    Payment.objects.create(invoice=inv, method=pay_method, amount=inv.total, date=date.today(), note='Demo payment')
        Discount.objects.get_or_create(code='WELCOME10', defaults={'name': 'Welcome 10% off', 'discount_type': 'percent', 'value': Decimal('10'), 'start_date': date.today(), 'end_date': date.today() + timedelta(days=90), 'usage_limit': 100})
        self.stdout.write(self.style.SUCCESS('Seed done.'))
        self.stdout.write('Main logins: admin@brightloop.test / Admin@1234 | staff@brightloop.test / Staff@1234 | customer@brightloop.test / Customer@1234')
        self.stdout.write('Dummy active customers (all password = Firstname@1234): priya@, rahul@, sneha@, arjun@, vikram@brightloop.test + staff neha@brightloop.test / Neha@1234')
        self.stdout.write('Active subscriptions now: SUB-0001 to SUB-0006 (SUB-0001 kept invoice-free for the live video demo).')
        self.stdout.write('Demo line: 2 x 1000 + 2 x 560 variant = 3120 subtotal, tax 18% = 561.60')
