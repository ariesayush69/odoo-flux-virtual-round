# Brightloop — Video Script (Last hour: 2:00-3:00pm, target 3-4 minutes)

## Title slide (show for 5 seconds, read it out)
Brightloop — Subscription Management System | Odoo Hackathon | Team: [your team name]
Stack: Django (Python) + SQLite | Frontend: Django templates

## Script — speak slowly, show the screen, do not read code
1. **Problem (30 sec):** "Brightloop sells software on subscription. Today they track it in spreadsheets, renewals get missed, invoices are typed by hand, and nobody knows real recurring revenue. We built one system to fix that."
2. **Login + roles (30 sec):** Login as Admin, then show Staff cannot add staff, Customer sees only own data. Mention password rule: more than 8 chars, upper, lower, special.
3. **Product + Plan (30 sec):** Show Brightloop CRM, variant Brand: Odoo +560, Plan Pro Monthly, monthly billing, min quantity.
4. **Subscription (30 sec):** Show SUB-0001, move Draft → Quotation → Confirmed → Active. Show lines with variant price.
5. **Invoice — the proof (45 sec):** Click Generate invoice. Show subtotal 3120, tax 561.60, total 3681.60. Click Generate again — show it blocks double billing.
6. **Payment + Discount (30 sec):** Record a payment, invoice becomes Paid when fully paid. Show an admin-only discount applying automatically on the next invoice.
7. **Dashboard + close (30 sec):** Show active subscriptions, revenue, outstanding, overdue, filters. Close: "One place for plans, subscriptions, invoices, payments and revenue — built in Django + SQLite, ready to use."

## Recording checklist
- Close extra tabs, turn on Do Not Disturb, zoom browser to 110% so text is readable
- Record in one take if possible; small mistakes are okay, judges care about working demo, not perfect editing
- End the video with the dashboard on screen, not a black screen
- Upload, copy the link, team leader submits repo link + video link before 3pm, screenshot confirmation
