from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import login
from django.core.paginator import Paginator
from django.db.models import Sum, Q, Count
from django.db.models.functions import TruncMonth
from django.http import HttpResponse
from django.utils import timezone
from datetime import date, timedelta
from decimal import Decimal
import csv, time
from .models import Profile, Product, Variant, Plan, QuotationTemplate, Subscription, SubscriptionLine, Invoice, InvoiceLine, Discount, Payment, SUB_ORDER
from .forms import SignupForm, ProductForm, VariantForm, PlanForm, TemplateForm, SubscriptionForm, SubscriptionLineForm, DiscountForm, PaymentForm, StaffForm

def role(user):
    return getattr(getattr(user, 'profile', None), 'role', 'customer')
def is_admin(user): return role(user) == 'admin'
def is_staff_or_admin(user): return role(user) in ('admin', 'staff')
def staff_required(view):
    def w(request, *args, **kwargs):
        if not request.user.is_authenticated or not is_staff_or_admin(request.user):
            messages.error(request, 'Staff or Admin only.')
            return redirect('dashboard')
        return view(request, *args, **kwargs)
    return w
def admin_required(view):
    def w(request, *args, **kwargs):
        if not request.user.is_authenticated or not is_admin(request.user):
            messages.error(request, 'Admin only.')
            return redirect('dashboard')
        return view(request, *args, **kwargs)
    return w

def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            user = User.objects.create_user(username=email, email=email, password=form.cleaned_data['password'])
            Profile.objects.create(user=user, role='customer')
            login(request, user)
            messages.success(request, 'Account created. You are a Customer - you see only your own data.')
            return redirect('portal')
    else:
        form = SignupForm()
    return render(request, 'form.html', {'form': form, 'title': 'Sign up (Customer)', 'hint': 'Password: more than 8 characters, 1 uppercase, 1 lowercase, 1 special character. One account per email.'})

@login_required
def dashboard(request):
    # Finance summary with aggregates only - fast even with thousands of rows.
    started = time.time()
    subs = Subscription.objects.all()
    if role(request.user) == 'customer':
        subs = subs.filter(customer=request.user)
    active = subs.filter(status='Active').count()
    invoices = Invoice.objects.all()
    if role(request.user) == 'customer':
        invoices = invoices.filter(customer=request.user)
    status_filter = request.GET.get('status', '')
    if status_filter:
        invoices = invoices.filter(status=status_filter)
    revenue = Payment.objects.filter(invoice__in=invoices).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    # Outstanding = Confirmed invoices only, minus payments already made on them.
    # (Old code subtracted ALL payments from Confirmed+Paid totals - same answer
    # only when Paid invoices were paid in full, and confusing to read.)
    confirmed_total = invoices.filter(status='Confirmed').aggregate(t=Sum('total'))['t'] or Decimal('0')
    confirmed_paid = Payment.objects.filter(invoice__in=invoices, invoice__status='Confirmed').aggregate(t=Sum('amount'))['t'] or Decimal('0')
    outstanding = confirmed_total - confirmed_paid
    overdue = invoices.filter(status='Confirmed', due_date__lt=date.today()).count()
    page = Paginator(invoices.order_by('-created_at'), 25).get_page(request.GET.get('page'))
    latency_ms = round((time.time() - started) * 1000, 1)
    return render(request, 'dashboard.html', {'active': active, 'revenue': revenue, 'outstanding': outstanding,
        'overdue': overdue, 'total_subs': subs.count(), 'invoices': page, 'status_filter': status_filter, 'role': role(request.user), 'latency_ms': latency_ms})

@login_required
def customer_portal(request):
    # PORTAL 3 - Customer: ONLY own data, never anyone else's.
    subs = Subscription.objects.filter(customer=request.user).order_by('-created_at')
    invs = Invoice.objects.filter(customer=request.user).order_by('-created_at')
    overdue_own = invs.filter(status='Confirmed', due_date__lt=date.today()).count()
    paid_own = Payment.objects.filter(invoice__customer=request.user).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    plans = Plan.objects.all().order_by('name')
    return render(request, 'portal.html', {'subs': subs, 'invs': invs, 'overdue_own': overdue_own, 'paid_own': paid_own, 'plans': plans})

@login_required
@admin_required
def admin_portal(request):
    # PORTAL 1 - Admin: full control, everything, everyone.
    started = time.time()
    staff_users = list(User.objects.filter(profile__role='staff'))
    customers = list(User.objects.filter(profile__role='customer'))
    ctx = {
        'total_products': Product.objects.count(), 'total_plans': Plan.objects.count(),
        'total_subs': Subscription.objects.count(), 'active_subs': Subscription.objects.filter(status='Active').count(),
        'total_invoices': Invoice.objects.count(), 'overdue': Invoice.objects.filter(status='Confirmed', due_date__lt=date.today()).count(),
        'revenue': Payment.objects.aggregate(t=Sum('amount'))['t'] or Decimal('0'),
        'discounts': list(Discount.objects.all()), 'staff_users': staff_users, 'customers': customers,
        'recent_invoices': list(Invoice.objects.order_by('-created_at')[:10]),
    }
    ctx['latency_ms'] = round((time.time() - started) * 1000, 1)
    return render(request, 'admin_portal.html', ctx)

@login_required
@staff_required
def staff_portal(request):
    # PORTAL 2 - Staff: day-to-day only. NO discount creation, NO staff creation here.
    # Those buttons simply do not appear on this page, and the views behind them block staff too.
    to_confirm = Invoice.objects.filter(status='Draft').order_by('-created_at')[:10]
    overdue = Invoice.objects.filter(status='Confirmed', due_date__lt=date.today())
    return render(request, 'staff_portal.html', {
        'active_subs': Subscription.objects.filter(status='Active').count(),
        'to_confirm': to_confirm, 'to_confirm_count': Invoice.objects.filter(status='Draft').count(),
        'overdue': overdue, 'overdue_count': overdue.count(),
        'recent_subs': Subscription.objects.order_by('-created_at')[:10],
        'recent_payments': Payment.objects.order_by('-date')[:10],
    })

@login_required
@staff_required
def product_list(request):
    q = request.GET.get('q', '')
    qs = Product.objects.all().prefetch_related('variants')
    if q: qs = qs.filter(Q(name__icontains=q) | Q(type__icontains=q))
    return render(request, 'products.html', {'products': qs, 'q': q})
@login_required
@staff_required
def product_detail(request, pk):
    p = get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product': p, 'plans': Plan.objects.filter(product=p), 'subs': Subscription.objects.filter(lines__product=p).distinct()})
@login_required
@staff_required
def product_create(request):
    form = ProductForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Product saved.'); return redirect('products')
    return render(request, 'form.html', {'form': form, 'title': 'New product'})
@login_required
@staff_required
def variant_list(request):
    q = request.GET.get('q', '')
    qs = Variant.objects.all().select_related('product')
    if q: qs = qs.filter(Q(name__icontains=q) | Q(product__name__icontains=q))
    return render(request, 'variants.html', {'variants': qs, 'q': q})
@login_required
@staff_required
def variant_create(request):
    form = VariantForm(request.POST or None)
    if form.is_valid():
        v = form.save(); messages.success(request, f'Variant saved: {v}.'); return redirect('products')
    return render(request, 'form.html', {'form': form, 'title': 'New variant — e.g. Brand: Odoo, price add 560'})

@login_required
@staff_required
def plan_list(request):
    q = request.GET.get('q', '')
    qs = Plan.objects.all()
    if q: qs = qs.filter(Q(name__icontains=q) | Q(billing_frequency__icontains=q))
    return render(request, 'plans.html', {'plans': qs, 'q': q})
@login_required
@staff_required
def plan_detail(request, pk):
    p = get_object_or_404(Plan, pk=pk)
    return render(request, 'plan_detail.html', {'plan': p, 'subs': Subscription.objects.filter(plan=p), 'templates': QuotationTemplate.objects.filter(plan=p)})
@login_required
@staff_required
def plan_create(request):
    form = PlanForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Plan saved.'); return redirect('plans')
    return render(request, 'form.html', {'form': form, 'title': 'New plan - set billing, min quantity, dates, auto-close / pause / renew per plan'})

@login_required
@staff_required
def template_list(request):
    q = request.GET.get('q', '')
    qs = QuotationTemplate.objects.all().select_related('plan')
    if q: qs = qs.filter(Q(name__icontains=q) | Q(plan__name__icontains=q))
    return render(request, 'templates.html', {'templates': qs, 'q': q})
@login_required
@staff_required
def template_create(request):
    form = TemplateForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Quotation template saved.'); return redirect('templates')
    return render(request, 'form.html', {'form': form, 'title': 'New quotation template — plan + validity in days'})

@login_required
def subscription_list(request):
    qs = Subscription.objects.all() if is_staff_or_admin(request.user) else Subscription.objects.filter(customer=request.user)
    q = request.GET.get('q', '')
    if q: qs = qs.filter(Q(number__icontains=q) | Q(customer__email__icontains=q))
    return render(request, 'subscriptions.html', {'subs': Paginator(qs.order_by('-created_at'), 25).get_page(request.GET.get('page')), 'q': q})
@login_required
@staff_required
def subscription_create(request):
    # /plans "Use this plan" links here as ?plan=<id> so the plan is pre-selected.
    initial = {}
    if request.GET.get('plan'):
        initial['plan'] = request.GET.get('plan')
    form = SubscriptionForm(request.POST or None, initial=initial)
    if form.is_valid():
        sub = form.save()
        messages.success(request, f'Subscription {sub.number} created in Draft. Add lines, then advance it.')
        return redirect('subscription_detail', pk=sub.pk)
    return render(request, 'form.html', {'form': form, 'title': 'New subscription'})
@login_required
def subscription_detail(request, pk):
    sub = get_object_or_404(Subscription, pk=pk)
    if role(request.user) == 'customer' and sub.customer != request.user:
        messages.error(request, 'You can only see your own subscriptions.'); return redirect('portal')
    return render(request, 'subscription_detail.html', {'sub': sub})
@login_required
@staff_required
def subscription_add_line(request, pk):
    sub = get_object_or_404(Subscription, pk=pk)
    form = SubscriptionLineForm(request.POST or None)
    if form.is_valid():
        line = form.save(commit=False); line.subscription = sub
        if line.quantity < sub.plan.min_quantity:
            messages.error(request, f"Quantity must be at least plan minimum {sub.plan.min_quantity}.")
        else:
            line.save(); messages.success(request, 'Line added.'); return redirect('subscription_detail', pk=pk)
    return render(request, 'form.html', {'form': form, 'title': f'Add line to {sub.number}'})
@login_required
@staff_required
def subscription_advance(request, pk):
    sub = get_object_or_404(Subscription, pk=pk)
    if sub.status in SUB_ORDER:
        i = SUB_ORDER.index(sub.status)
        if i < len(SUB_ORDER) - 1:
            sub.status = SUB_ORDER[i + 1]; sub.save(); messages.success(request, f'Moved to {sub.status}.')
        else:
            messages.info(request, 'Already Closed.')
    return redirect('subscription_detail', pk=pk)
@login_required
@staff_required
def subscription_pause(request, pk):
    sub = get_object_or_404(Subscription, pk=pk)
    if not sub.plan.allow_pause:
        messages.error(request, 'This plan does not allow pause.')
    else:
        sub.status = 'Paused'; sub.save(); messages.success(request, 'Paused.')
    return redirect('subscription_detail', pk=pk)
@login_required
@staff_required
def subscription_renew(request, pk):
    sub = get_object_or_404(Subscription, pk=pk)
    if not sub.plan.allow_renew:
        messages.error(request, 'This plan does not allow renew.')
    else:
        sub.status = 'Active'; sub.expiry_date = sub.expiry_date + timedelta(days=30); sub.save(); messages.success(request, 'Renewed - Active, expiry +30 days (demo rule).')
    return redirect('subscription_detail', pk=pk)

def make_invoice(sub, period):
    """Return (invoice, created, message). Shared by single + bulk generation."""
    if Invoice.objects.filter(subscription=sub, billing_period=period).exists():
        return None, False, 'already invoiced for this period - skipped, not duplicated'
    lines = sub.lines.all()
    if not lines:
        return None, False, 'no lines - skipped'
    subtotal = sum((l.amount for l in lines), Decimal('0'))
    tax_total = sum((l.tax_amount for l in lines), Decimal('0'))
    qty = sum(l.quantity for l in lines)
    discount_total = Decimal('0')
    for d in Discount.objects.all():
        if d.is_active_on(date.today(), subtotal, qty):
            if d.product is None or any(l.product_id == d.product_id for l in lines):
                discount_total = d.amount_for(subtotal)
                d.used_count += 1; d.save(); break
    inv = Invoice.objects.create(subscription=sub, customer=sub.customer, billing_period=period,
        subtotal=subtotal, tax_total=tax_total, discount_total=discount_total,
        total=subtotal + tax_total - discount_total, due_date=date.today() + timedelta(days=30))
    for l in lines:
        InvoiceLine.objects.create(invoice=inv, product=l.product, quantity=l.quantity, unit_price=l.unit_price, tax_amount=l.tax_amount, amount=l.amount)
    return inv, True, f'created, total {inv.total}, discount {discount_total}'

@login_required
@staff_required
def invoice_generate(request, pk):
    """Create invoice from subscription. Unique (subscription, billing_period) blocks double billing."""
    sub = get_object_or_404(Subscription, pk=pk)
    period = date.today().replace(day=1)
    inv, created, msg = make_invoice(sub, period)
    if not created:
        messages.error(request, f'{sub.number}: {msg}.')
        return redirect('invoices')
    messages.success(request, f'Invoice {inv.number} created in Draft. {msg}.')
    return redirect('invoice_detail', pk=inv.pk)

@login_required
def invoice_list(request):
    qs = Invoice.objects.all() if is_staff_or_admin(request.user) else Invoice.objects.filter(customer=request.user)
    return render(request, 'invoices.html', {'invs': Paginator(qs.order_by('-created_at'), 25).get_page(request.GET.get('page'))})
@login_required
def invoice_detail(request, pk):
    inv = get_object_or_404(Invoice, pk=pk)
    if role(request.user) == 'customer' and inv.customer != request.user:
        messages.error(request, 'You can only see your own invoices.'); return redirect('portal')
    return render(request, 'invoice_detail.html', {'inv': inv})
@login_required
@staff_required
def invoice_action(request, pk, action):
    inv = get_object_or_404(Invoice, pk=pk)
    if action == 'confirm': inv.status = 'Confirmed'
    elif action == 'cancel': inv.status = 'Cancelled'
    elif action == 'send': inv.sent = True; messages.success(request, 'Marked as sent. (Demo: no real email configured.)')
    elif action == 'paid': inv.status = 'Paid'
    else: messages.error(request, 'Unknown action.'); return redirect('invoice_detail', pk=pk)
    inv.save(); messages.success(request, f'Invoice {inv.number} -> {inv.status}.')
    return redirect('invoice_detail', pk=pk)

@login_required
@admin_required
def discount_create(request):
    form = DiscountForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Discount created - admin only. It will apply automatically on the next invoice.'); return redirect('discounts')
    return render(request, 'form.html', {'form': form, 'title': 'New discount (Admin only)'})
@login_required
@staff_required
def discount_list(request):
    q = request.GET.get('q', '')
    qs = Discount.objects.all()
    if q: qs = qs.filter(Q(name__icontains=q) | Q(code__icontains=q))
    return render(request, 'discounts.html', {'discounts': qs, 'q': q})

@login_required
@staff_required
def payment_create(request):
    form = PaymentForm(request.POST or None)
    if form.is_valid():
        pay = form.save()
        inv = pay.invoice
        if inv.paid_amount >= inv.total and inv.total > 0:
            inv.status = 'Paid'; inv.save()
        messages.success(request, f'Payment {pay.amount} recorded for {inv.number}.')
        return redirect('invoice_detail', pk=inv.pk)
    return render(request, 'form.html', {'form': form, 'title': 'Record payment (method, amount, date, note)'})
@login_required
def payment_list(request):
    q = request.GET.get('q', '')
    qs = Payment.objects.all() if is_staff_or_admin(request.user) else Payment.objects.filter(invoice__customer=request.user)
    if q: qs = qs.filter(Q(invoice__number__icontains=q) | Q(method__icontains=q))
    return render(request, 'payments.html', {'payments': qs.order_by('-date'), 'q': q})

@login_required
@admin_required
def staff_create(request):
    # Only admin can add staff - enforced by decorator + this view.
    form = StaffForm(request.POST or None)
    if form.is_valid():
        email = form.cleaned_data['email']
        user = User.objects.create_user(username=email, email=email, password=form.cleaned_data['password'])
        Profile.objects.create(user=user, role='staff')
        messages.success(request, f'Staff {email} created.')
        return redirect('dashboard')
    return render(request, 'form.html', {'form': form, 'title': 'Add staff (Admin only)'})

@login_required
@staff_required
def auto_close_subscriptions(request):
    if request.method != 'POST':
        return redirect('subscriptions')
    today = date.today()
    qs = Subscription.objects.filter(status='Active', expiry_date__lt=today, plan__auto_close=True)
    count = qs.count()
    qs.update(status='Closed')
    messages.success(request, f'Auto-close check done: {count} expired subscription(s) with auto_close plans closed.')
    return redirect('subscriptions')

@login_required
@staff_required
def bulk_invoice(request):
    results = None
    if request.method == 'POST':
        period_str = request.POST.get('billing_period', '')
        try:
            y, m, _d = [int(x) for x in period_str.split('-')]
            period = date(y, m, 1)
        except Exception:
            messages.error(request, 'Enter a valid billing period date.'); return redirect('invoices_bulk')
        results = []
        for sub in Subscription.objects.filter(status='Active').order_by('number'):
            inv, created, msg = make_invoice(sub, period)
            results.append((sub.number, sub.customer.email, inv.number if inv else '-', msg))
        messages.success(request, f'Bulk run done for {period}: {sum(1 for r in results if r[2] != "-")} created.')
    return render(request, 'bulk_invoice.html', {'results': results})

@login_required
@staff_required
def reports(request):
    by_month = Payment.objects.annotate(month=TruncMonth('date')).values('month').annotate(revenue=Sum('amount'), count=Count('id')).order_by('-month')[:12]
    by_plan = Invoice.objects.values('subscription__plan__name').annotate(revenue=Sum('total'), count=Count('id')).order_by('-revenue')
    top = Payment.objects.values('invoice__customer__email').annotate(revenue=Sum('amount')).order_by('-revenue')[:10]
    overdue_list = Invoice.objects.filter(status='Confirmed', due_date__lt=date.today()).order_by('due_date')
    outstanding_by_customer = Invoice.objects.filter(status='Confirmed').values('customer__email').annotate(total=Sum('total')).order_by('-total')
    return render(request, 'reports.html', {'by_month': by_month, 'by_plan': by_plan, 'top': top, 'overdue_list': overdue_list, 'outstanding_by_customer': outstanding_by_customer})

@login_required
@staff_required
def invoice_export(request):
    resp = HttpResponse(content_type='text/csv'); resp['Content-Disposition'] = 'attachment; filename="invoices.csv"'
    w = csv.writer(resp); w.writerow(['number', 'customer', 'subscription', 'billing_period', 'status', 'subtotal', 'tax_total', 'discount_total', 'total', 'due_date'])
    for inv in Invoice.objects.all().order_by('number'):
        w.writerow([inv.number, inv.customer.email, inv.subscription.number, inv.billing_period, inv.status, inv.subtotal, inv.tax_total, inv.discount_total, inv.total, inv.due_date])
    return resp

@login_required
@staff_required
def payment_export(request):
    resp = HttpResponse(content_type='text/csv'); resp['Content-Disposition'] = 'attachment; filename="payments.csv"'
    w = csv.writer(resp); w.writerow(['invoice', 'customer', 'method', 'amount', 'date', 'note'])
    for p in Payment.objects.all().order_by('-date'):
        w.writerow([p.invoice.number, p.invoice.customer.email, p.method, p.amount, p.date, p.note])
    return resp
